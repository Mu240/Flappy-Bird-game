import random #to generate random numbers
import sys #to use as exit for program
import pygame
from pygame.locals import * #Basic imports of pygame
#Global variables for game
FPS = 32
ScreenWidth = 289 
ScreenHeight = 511
Screen = pygame.display.set_mode((ScreenWidth,ScreenHeight))
Groundy = ScreenHeight * 0.8
Game_sprites = {} 
Game_sounds = {}
Player = 'gallery/sprites/bird.png' 
Background = 'gallery/sprites/background.png' 
Pipe = 'gallery/sprites/pipe.png'

def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    Screen.blit(img, (x, y))


def WelcomeScreen():
    Playerx = int(ScreenWidth/5)
    Playery = int((ScreenHeight - Game_sprites['player'].get_height())/2)
    messagex = int((ScreenWidth - Game_sprites['message'].get_width())/2)
    messagey = int(ScreenHeight * 0.13)
    basex = 0
    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            elif event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP):    
                return
            else:
                Screen.blit(Game_sprites['background'],(0,0)) 
                Screen.blit(Game_sprites['player'],(Playerx,Playery)) 
                Screen.blit(Game_sprites['message'],(messagex,messagey)) 
                Screen.blit(Game_sprites['base'],(basex,Groundy)) 
                pygame.display.update()
                FPSClock.tick(FPS)

def MainGame():
    score = 0
    Playerx = int(ScreenWidth/5)
    Playery = int(ScreenWidth/2)
    basex = 0
    newPipe1 = getRandompipe()
    newPipe2 = getRandompipe()
    upperpipes = [{'x': ScreenWidth + 200,'y': newPipe1[0]['y']},{'x': ScreenWidth + 200 + (ScreenWidth/2),'y': newPipe2[0]['y']},]
    lowerpipes = [{'x': ScreenWidth + 200,'y': newPipe1[1]['y']},{'x': ScreenWidth + 200 + (ScreenWidth/2),'y': newPipe2[1]['y']},]
    pipevelx = -4
    playervely = -9
    playermaxvely = 10
    playerminvely = -8
    playeraccy = 1
    playerflapaccv = -8
    playerflap = False

    while True:
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN and (event.key == K_SPACE or event.key == K_UP): 
                if Playery > 0:
                    playervely = playerflapaccv
                    playerflap = True
                    Game_sounds['wing'].play()


        crashtest = iscollide(Playerx,Playery,upperpipes,lowerpipes,score)  
        if crashtest:
            return

        playermidpos = Playerx + Game_sprites['player'].get_width()/2
        for pipe in upperpipes:
            pipemidpos = pipe['x'] + Game_sprites['pipe'][0].get_width()/2
            if pipemidpos <= playermidpos < pipemidpos +4:
                score += 1
                print(f"Your score is {score}")             
                Game_sounds['point'].play()
                  
                

                 
        if playervely < playermaxvely and not playerflap:
            playervely += playeraccy

        if playerflap:
            playerflap = False
        playerheight = Game_sprites['player'].get_height()
        Playery = Playery + min(playervely,Groundy - Playery - playerheight)

        for upperpipe , lowerpipe in zip(upperpipes,lowerpipes):
            upperpipe['x'] += pipevelx                                
            lowerpipe['x'] += pipevelx    

        if 0<upperpipes[0]['x']<5:
            newpipe = getRandompipe()
            upperpipes.append(newpipe[0])    
            lowerpipes.append(newpipe[1])  

        if upperpipes[0]['x'] < -Game_sprites['pipe'][0].get_width():
            upperpipes.pop(0)      
            lowerpipes.pop(0)      

        Screen.blit(Game_sprites['background'],(0,0))
        for upperpipe , lowerpipe in zip(upperpipes,lowerpipes):
            Screen.blit(Game_sprites['pipe'][0],(upperpipe['x'],upperpipe['y']))   
            Screen.blit(Game_sprites['pipe'][1],(lowerpipe['x'],lowerpipe['y']))   

        Screen.blit(Game_sprites['base'],(basex,Groundy))
        Screen.blit(Game_sprites['player'],(Playerx,Playery))
        mydigits = [int(x) for x in list(str(score))]
        width = 0
        for digit in mydigits:
            width += Game_sprites['numbers'][digit].get_width()
        Xoffset = (ScreenWidth - width)/2
        
        for digit in mydigits:
            Screen.blit(Game_sprites['numbers'][digit],(Xoffset,ScreenHeight * 0.12 ))
            Xoffset += Game_sprites['numbers'][digit].get_width()
        pygame.display.update()
        FPSClock.tick(FPS)
                 


def iscollide(Playerx,Playery,upperpipes,lowerpipes,score):
    if Playery > Groundy - 25 or Playery < 0:
        Game_sounds['hit'].play()
        return True
    for pipe in upperpipes:
        pipeheight = Game_sprites['pipe'][0].get_height()
        if (Playery < pipeheight + pipe['y'] and abs(Playerx - pipe['x']) < Game_sprites['pipe'][0].get_width()):
            Game_sounds['hit'].play()
            print(f" score is {score}")        
            draw_text(f"High Score: {score}", text_font, (0, 0, 0), 80, 430)
            pygame.display.flip()
            return True
    for pipe in lowerpipes:        
        if (Playery + Game_sprites['player'].get_height() > pipe['y']) and abs(Playerx - pipe['x']) < Game_sprites['pipe'][0].get_width():
            Game_sounds['hit'].play()
            print(f" score is {score}")        
            draw_text(f"High Score: {score}", text_font, (0, 0, 0), 80, 430)
            pygame.display.flip()
            return True     

    return False


def getRandompipe():
    pipeheight = Game_sprites['pipe'][0].get_height()
    offset = ScreenHeight / 3
    y2 = offset + random.randrange(0,int(ScreenHeight - Game_sprites['base'].get_height() - 1.2 * offset))
    pipex = ScreenWidth + 10
    y1 = pipeheight - y2 + offset
    pipe = [{'x': pipex,'y': -y1},{'x': pipex,'y': y2}]
    return pipe







if __name__ == "__main__":
    #This is the part from where game will start
    pygame.init()
    FPSClock = pygame.time.Clock()
    text_font = pygame.font.SysFont("Helvetica", 30)
    pygame.display.set_caption('Flappy Bird Game By Hassan')
    #Game images
    Game_sprites['numbers'] = (
        pygame.image.load('gallery/sprites/0.png').convert_alpha(),
        pygame.image.load('gallery/sprites/1.png').convert_alpha(),
        pygame.image.load('gallery/sprites/2.png').convert_alpha(),
        pygame.image.load('gallery/sprites/3.png').convert_alpha(),
        pygame.image.load('gallery/sprites/4.png').convert_alpha(),
        pygame.image.load('gallery/sprites/5.png').convert_alpha(),
        pygame.image.load('gallery/sprites/6.png').convert_alpha(),
        pygame.image.load('gallery/sprites/7.png').convert_alpha(),
        pygame.image.load('gallery/sprites/8.png').convert_alpha(),
        pygame.image.load('gallery/sprites/9.png').convert_alpha()
    )
    Game_sprites['message'] = pygame.image.load('gallery/sprites/message.png').convert_alpha()
    Game_sprites['base'] = pygame.image.load('gallery/sprites/base.png').convert_alpha()
    Game_sprites['pipe'] = (pygame.transform.rotate(pygame.image.load(Pipe).convert_alpha(),180),pygame.image.load(Pipe).convert_alpha()) 
    Game_sprites['background'] = pygame.image.load(Background).convert()
    Game_sprites['player'] = pygame.image.load(Player).convert_alpha()
    #Game sounds
    Game_sounds['die'] = pygame.mixer.Sound('gallery/audio/die.wav')    
    Game_sounds['hit'] = pygame.mixer.Sound('gallery/audio/hit.wav')    
    Game_sounds['point'] = pygame.mixer.Sound('gallery/audio/point.wav')    
    Game_sounds['swoosh'] = pygame.mixer.Sound('gallery/audio/swoosh.wav')    
    Game_sounds['wing'] = pygame.mixer.Sound('gallery/audio/wing.wav') 
    while True:
        WelcomeScreen()
        MainGame()   

 
